import React from 'react';
function HelloWorld() {
  return <div>Hello, World!</div>;
}
export default HelloWorld;
