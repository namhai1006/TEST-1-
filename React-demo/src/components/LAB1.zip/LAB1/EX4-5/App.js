import React from "react";
import CourseList from "./CourseList"; // Adjust the path as necessary


const App = () => {
  return (
    <div>
      <h1>My Courses</h1>
      <CourseList />
    </div>
  );
};


export default App;