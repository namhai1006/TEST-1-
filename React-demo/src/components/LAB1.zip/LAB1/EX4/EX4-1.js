import React from "react";
import "./App.css"; // Make sure to create this CSS file with the styles provided below


const App = () => {
  return (
    <div className="hello-react">
      Hello <span className="react-text">React</span>
    </div>
  );
};


export default App;
