import React, { Component } from "react";

import '../EX4/App_.css';

class App extends Component {
    render() {
        return (
            <div>
                <h1>This is JSX</h1>
            </div>
        );
    }
}

export default App;